from . import ops_vms


def register():
    ops_vms.register()


def unregister():
    ops_vms.unregister()